<div class="text-blue-400 text-xl">
  <i class="fas fa-cloud"></i> <b>Blog - SMK Cloud Provider</b>
</div>
